package org.OpenNI.Samples.Assistant;

public class OutArg<T> 
{
	public T value;
}
